const path = require("path");
const express = require('express');
const bodyParser = require('body-parser'); 
const app = express();

const host = "127.0.0.1"
const port = 3000


app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static("public"));

function addera(tal) {
    let strNumbersArr = tal.split(","); // ["10", "343", "24", ..., "233"]
    let sum = 0;
    for(let i = 0; i < strNumbersArr.length; i++) {
        let currentNumberStr = strNumbersArr[i];
    sum += Number(currentNumberStr); // convert current number string into a number
    }
    return sum;
}


app.post('/add', (req, res) => {
    console.log(req);
    let sum = addera(req.body.tal);  
    console.log(sum);

    res.send({Sum: sum});
});


app.listen(port, host, () => {
    console.log(`The server is running at: http://${host}:${port}`);
});
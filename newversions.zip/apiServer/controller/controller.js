const fetch = require('node-fetch');
const loadTeam = require('../model/teamModel');

const express = require("express");
const app = express();
const bodyParser = require('body-parser'); 

exports.listTeam = (req, res) => {
    
    loadTeam()
    .then(function (data) {
        console.log(data);
        console.log("This is inside controller")
        res.send(data);
    })
    .catch(error => console.log(error))
}

exports.renderSum = (req, res) => {
            console.log(req.body.tal);
            //make post to mathsServer
            fetch('http://127.0.0.1:3000/add', { method: 'POST', body: JSON.stringify(req.body), headers: { 'Content-Type': 'application/json' } }).then(
                mathsServerResponse => mathsServerResponse.json())//first get json from response
                .then( mathsServerResponse => {
                    res.send( mathsServerResponse );//next send json back to original caller
                }
            ).catch(error => console.log(error))
    
}

      
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.json());

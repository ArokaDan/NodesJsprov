const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser'); 
const path =require('path');
const teamRouter  = require('./routes/teamRouter');
const mathRouter  = require('./routes/mathRouter');
const app = express();

const host = "127.0.0.1"
const port = process.env.PORT || 3002;
 
app.use(express.static(path.join(__dirname, '../web-client/views')));
app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use('/list', teamRouter);   // TEST: POSTMAN - GET-Request:  http://127.0.0.1:3000/list/team
app.use('/math', mathRouter);    // TEST: POSTMAN - POST- http://127.0.0.1:3002/math/add Request: { "tal": "10,343,24,345,22,23,233,45" }


app.get('*', function (req, res) {
    res.status(404);
    res.send('NOT ALLOWED');
});

app.post('*', function (req, res) {
    res.status(404);
    res.send('NOT ALLOWED');
});

app.listen(port, host, () => {
    console.log(`The server is running at: http://${host}:${port}`);
});



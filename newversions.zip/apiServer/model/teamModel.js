'use strict';

const fs = require('fs/promises');

const loadTeam = async () => {  
    try {
        let rawData = await fs.readFile('../web-client/json/prov-nodes.json')
        let team = JSON.parse(rawData);

        console.log("Inside loadTeams()");
        console.log(team);

        return team;

    } catch (error) {
        console.log(error)
    }
    console.log('This is after the read call.....loadTeams()');
}

module.exports = loadTeam;

